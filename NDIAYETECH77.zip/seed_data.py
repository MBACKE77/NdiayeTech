"""
seed_data.py - Insérer des projets de démonstration
Lancer ce script une seule fois pour pré-remplir la base.
"""

import os, sys, json

os.makedirs("data", exist_ok=True)

projets = [
    {
        "libelle": "Site e-commerce",
        "description": "Développement d'un site de vente en ligne avec panier, paiement Stripe et gestion des commandes.",
        "technologies": ["Django", "PostgreSQL", "Stripe API", "Bootstrap"],
        "competences": ["Développement web full-stack", "Intégration API de paiement", "Modélisation BDD"],
        "date_creation": "2024-09-15",
        "lien_github": "https://github.com/exemple/ecommerce",
        "lien_demo": "https://demo.exemple.com",
        "image_path": ""
    },
    {
        "libelle": "Application mobile de suivi sportif",
        "description": "App React Native permettant de suivre ses entraînements, calories et objectifs hebdomadaires.",
        "technologies": ["React Native", "Firebase", "Expo", "Redux"],
        "competences": ["Développement mobile cross-platform", "Gestion d'état Redux", "NoSQL Firebase"],
        "date_creation": "2024-11-02",
        "lien_github": "https://github.com/exemple/sport-tracker",
        "lien_demo": "",
        "image_path": ""
    },
    {
        "libelle": "Système de gestion scolaire",
        "description": "Logiciel desktop Python pour gérer élèves, notes, emplois du temps et bulletins PDF.",
        "technologies": ["Python", "tkinter", "SQLite", "ReportLab"],
        "competences": ["POO Python", "Génération de rapports PDF", "Gestion de bases de données locales"],
        "date_creation": "2025-01-20",
        "lien_github": "",
        "lien_demo": "",
        "image_path": ""
    },
    {
        "libelle": "Dashboard analytique",
        "description": "Tableau de bord interactif pour visualiser des données de ventes en temps réel.",
        "technologies": ["Python", "Dash", "Plotly", "Pandas"],
        "competences": ["Data visualisation", "Analyse de données", "Déploiement Heroku"],
        "date_creation": "2025-03-10",
        "lien_github": "https://github.com/exemple/dashboard",
        "lien_demo": "https://dashboard.exemple.com",
        "image_path": ""
    },
    {
        "libelle": "Chatbot de support client",
        "description": "Bot intégré à une interface web pour répondre automatiquement aux questions fréquentes des clients.",
        "technologies": ["Python", "FastAPI", "OpenAI API", "Vue.js"],
        "competences": ["Intégration d'IA générative", "Développement API REST", "Frontend Vue.js"],
        "date_creation": "2025-05-01",
        "lien_github": "https://github.com/exemple/chatbot",
        "lien_demo": "",
        "image_path": ""
    },
]

with open("data/projets.json", "w", encoding="utf-8") as f:
    json.dump(projets, f, indent=2, ensure_ascii=False)

print(f"✓ {len(projets)} projets insérés dans data/projets.json")
