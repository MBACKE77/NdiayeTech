"""
dialogs.py - Boîtes de dialogue de l'application Portfolio
"""

import tkinter as tk
from tkinter import ttk, messagebox
from models import Projet, PortfolioManager

# ─── Palette (doit rester cohérente avec app.py) ──────────────────────────────

COLORS = {
    "bg_dark":     "#0f0f1a",
    "bg_card":     "#1a1a2e",
    "bg_sidebar":  "#12122a",
    "accent":      "#7c3aed",
    "accent2":     "#a855f7",
    "accent_soft": "#2d1b69",
    "text":        "#e2e8f0",
    "text_muted":  "#94a3b8",
    "text_dim":    "#475569",
    "success":     "#22c55e",
    "danger":      "#ef4444",
    "warning":     "#f59e0b",
    "border":      "#2d2d4e",
    "hover":       "#252540",
    "input_bg":    "#111128",
}

FONTS = {
    "title":  ("Georgia", 16, "bold"),
    "sub":    ("Helvetica", 11, "bold"),
    "body":   ("Helvetica", 10),
    "small":  ("Helvetica", 9),
    "btn":    ("Helvetica", 10, "bold"),
    "label":  ("Helvetica", 10),
}


def _style_entry(widget):
    widget.configure(
        bg=COLORS["input_bg"], fg=COLORS["text"],
        insertbackground=COLORS["accent2"],
        relief="flat", highlightthickness=1,
        highlightbackground=COLORS["border"],
        highlightcolor=COLORS["accent"],
        font=FONTS["body"]
    )


def _style_text(widget):
    widget.configure(
        bg=COLORS["input_bg"], fg=COLORS["text"],
        insertbackground=COLORS["accent2"],
        relief="flat", highlightthickness=1,
        highlightbackground=COLORS["border"],
        highlightcolor=COLORS["accent"],
        font=FONTS["body"], wrap="word"
    )


def _make_btn(parent, text, cmd, style="normal"):
    if style == "primary":
        bg, fg, abg = COLORS["accent"], COLORS["text"], COLORS["accent2"]
    elif style == "danger":
        bg, fg, abg = COLORS["danger"], COLORS["text"], "#ff6666"
    elif style == "ghost":
        bg, fg, abg = COLORS["bg_card"], COLORS["text_muted"], COLORS["hover"]
    else:
        bg, fg, abg = COLORS["bg_sidebar"], COLORS["text"], COLORS["hover"]

    btn = tk.Button(parent, text=text, command=cmd, font=FONTS["btn"],
                    fg=fg, bg=bg, activeforeground=COLORS["text"],
                    activebackground=abg, relief="flat", cursor="hand2",
                    padx=14, pady=6, bd=0)
    return btn


class BaseDialog(tk.Toplevel):
    """Fenêtre modale de base."""

    def __init__(self, parent, title, width=520, height=480):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=COLORS["bg_dark"])
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        # Centrer
        parent.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - width) // 2
        y = parent.winfo_y() + (parent.winfo_height() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")

    def _header(self, parent, text, sub=None):
        h = tk.Frame(parent, bg=COLORS["accent_soft"])
        h.pack(fill="x")
        tk.Label(h, text=text, font=FONTS["title"],
                 fg=COLORS["accent2"], bg=COLORS["accent_soft"],
                 padx=20, pady=14).pack(anchor="w")
        if sub:
            tk.Label(h, text=sub, font=FONTS["small"],
                     fg=COLORS["text_muted"], bg=COLORS["accent_soft"],
                     padx=20, pady=4).pack(anchor="w")

    def _lbl(self, parent, text):
        tk.Label(parent, text=text, font=FONTS["label"],
                 fg=COLORS["text_muted"], bg=COLORS["bg_dark"],
                 anchor="w").pack(fill="x", padx=20, pady=(8, 1))


# ─────────────────────────────────────────────────────────────────────────────
#  LoginDialog
# ─────────────────────────────────────────────────────────────────────────────

class LoginDialog(BaseDialog):
    def __init__(self, parent, manager: PortfolioManager):
        super().__init__(parent, "Connexion", 400, 320)
        self.manager = manager
        self._build()

    def _build(self):
        self._header(self, "🔐 Connexion", "Entrez vos identifiants.")

        self._lbl(self, "Nom d'utilisateur")
        self.var_user = tk.StringVar()
        e = tk.Entry(self, textvariable=self.var_user, width=38)
        _style_entry(e)
        e.pack(padx=20, ipady=5)
        e.focus()

        self._lbl(self, "Mot de passe")
        self.var_pass = tk.StringVar()
        ep = tk.Entry(self, textvariable=self.var_pass, show="●", width=38)
        _style_entry(ep)
        ep.pack(padx=20, ipady=5)
        ep.bind("<Return>", lambda e: self._login())

        self.lbl_err = tk.Label(self, text="", fg=COLORS["danger"],
                                 bg=COLORS["bg_dark"], font=FONTS["small"])
        self.lbl_err.pack(pady=4)

        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(pady=10)
        _make_btn(row, "Connexion", self._login, "primary").pack(side="left", padx=6)
        _make_btn(row, "Annuler", self.destroy, "ghost").pack(side="left", padx=6)

        # Rappel compte par défaut
        tk.Label(self, text="Compte admin par défaut : admin / admin123",
                 font=FONTS["small"], fg=COLORS["text_dim"],
                 bg=COLORS["bg_dark"]).pack(pady=4)

    def _login(self):
        ok = self.manager.login(self.var_user.get().strip(),
                                self.var_pass.get())
        if ok:
            self.destroy()
        else:
            self.lbl_err.configure(text="Identifiants incorrects.")


# ─────────────────────────────────────────────────────────────────────────────
#  ProjetFormDialog
# ─────────────────────────────────────────────────────────────────────────────

class ProjetFormDialog(BaseDialog):
    """Formulaire d'ajout / modification d'un projet."""

    def __init__(self, parent, title="Projet", projet: Projet = None):
        super().__init__(parent, title, 580, 620)
        self.projet = projet
        self.result = None
        self._build()
        if projet:
            self._populate(projet)

    def _build(self):
        # Zone scrollable
        canvas = tk.Canvas(self, bg=COLORS["bg_dark"], highlightthickness=0)
        vsb = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True)

        inner = tk.Frame(canvas, bg=COLORS["bg_dark"])
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))

        title_text = "✏️  Modifier le projet" if self.projet else "➕ Nouveau projet"
        self._header(inner, title_text)

        def field(label, var_name, multiline=False, height=3):
            tk.Label(inner, text=label, font=FONTS["label"],
                     fg=COLORS["text_muted"], bg=COLORS["bg_dark"],
                     anchor="w").pack(fill="x", padx=20, pady=(10, 1))
            if multiline:
                w = tk.Text(inner, height=height, width=58)
                _style_text(w)
                w.pack(padx=20, pady=1, fill="x")
                setattr(self, var_name, w)
            else:
                var = tk.StringVar()
                w = tk.Entry(inner, textvariable=var, width=58)
                _style_entry(w)
                w.pack(padx=20, ipady=5, pady=1)
                setattr(self, var_name, var)

        field("Libellé *", "var_libelle")
        field("Description *", "var_desc", multiline=True, height=4)
        field("Technologies (séparées par des virgules) *", "var_tech")
        field("Compétences acquises (séparées par des virgules) *", "var_comp")
        field("Lien GitHub (optionnel)", "var_github")
        field("Lien démo (optionnel)", "var_demo")

        self.lbl_err = tk.Label(inner, text="", fg=COLORS["danger"],
                                 bg=COLORS["bg_dark"], font=FONTS["small"])
        self.lbl_err.pack(pady=4)

        row = tk.Frame(inner, bg=COLORS["bg_dark"])
        row.pack(pady=14)
        label_btn = "Enregistrer" if self.projet else "Ajouter"
        _make_btn(row, label_btn, self._submit, "primary").pack(side="left", padx=6)
        _make_btn(row, "Annuler", self.destroy, "ghost").pack(side="left", padx=6)

    def _populate(self, p: Projet):
        self.var_libelle.set(p.libelle)
        self.var_desc.insert("1.0", p.description)
        techs = p.technologies if isinstance(p.technologies, list) else p.technologies
        self.var_tech.set(", ".join(techs) if isinstance(techs, list) else techs)
        comps = p.competences if isinstance(p.competences, list) else p.competences
        self.var_comp.set(", ".join(comps) if isinstance(comps, list) else comps)
        self.var_github.set(p.lien_github or "")
        self.var_demo.set(p.lien_demo or "")

    def _submit(self):
        libelle = self.var_libelle.get().strip()
        desc = self.var_desc.get("1.0", "end").strip()
        tech_raw = self.var_tech.get().strip()
        comp_raw = self.var_comp.get().strip()

        if not libelle or not desc or not tech_raw or not comp_raw:
            self.lbl_err.configure(text="Les champs marqués * sont obligatoires.")
            return

        techs = [t.strip() for t in tech_raw.split(",") if t.strip()]
        comps = [c.strip() for c in comp_raw.split(",") if c.strip()]

        self.result = Projet(
            libelle=libelle,
            description=desc,
            technologies=techs,
            competences=comps,
            date_creation=self.projet.date_creation if self.projet else None,
            lien_github=self.var_github.get().strip(),
            lien_demo=self.var_demo.get().strip(),
        )
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
#  ConfirmDialog
# ─────────────────────────────────────────────────────────────────────────────

class ConfirmDialog(BaseDialog):
    def __init__(self, parent, message, detail=""):
        super().__init__(parent, "Confirmation", 380, 200)
        self.confirmed = False
        self._build(message, detail)

    def _build(self, message, detail):
        tk.Label(self, text="⚠️", font=("Helvetica", 32),
                 fg=COLORS["warning"], bg=COLORS["bg_dark"]).pack(pady=(20, 4))
        tk.Label(self, text=message, font=FONTS["sub"],
                 fg=COLORS["text"], bg=COLORS["bg_dark"]).pack()
        if detail:
            tk.Label(self, text=detail, font=FONTS["small"],
                     fg=COLORS["text_muted"], bg=COLORS["bg_dark"]).pack(pady=4)
        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(pady=16)
        _make_btn(row, "Supprimer", self._confirm, "danger").pack(side="left", padx=6)
        _make_btn(row, "Annuler", self.destroy, "ghost").pack(side="left", padx=6)

    def _confirm(self):
        self.confirmed = True
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
#  SearchDialog
# ─────────────────────────────────────────────────────────────────────────────

class SearchDialog(BaseDialog):
    def __init__(self, parent, manager: PortfolioManager):
        super().__init__(parent, "Rechercher", 460, 180)
        self.manager = manager
        self.results = None
        self._build()

    def _build(self):
        self._header(self, "🔍 Rechercher un projet")
        self._lbl(self, "Mot-clé (libellé, description, techno)")
        self.var_q = tk.StringVar()
        e = tk.Entry(self, textvariable=self.var_q, width=50)
        _style_entry(e)
        e.pack(padx=20, ipady=6, pady=4)
        e.bind("<Return>", lambda ev: self._search())
        e.focus()

        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(pady=10)
        _make_btn(row, "Rechercher", self._search, "primary").pack(side="left", padx=6)
        _make_btn(row, "Tout afficher", self._show_all, "ghost").pack(side="left", padx=6)
        _make_btn(row, "Fermer", self.destroy, "ghost").pack(side="left", padx=6)

    def _search(self):
        q = self.var_q.get().strip()
        if not q:
            return
        self.results = self.manager.rechercher_projets(q)
        self.destroy()

    def _show_all(self):
        self.results = self.manager.get_projets()
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
#  UserManagerDialog
# ─────────────────────────────────────────────────────────────────────────────

class UserManagerDialog(BaseDialog):
    def __init__(self, parent, manager: PortfolioManager):
        super().__init__(parent, "Gestion des utilisateurs", 520, 480)
        self.manager = manager
        self._build()

    def _build(self):
        self._header(self, "👥 Utilisateurs", "Gérer les comptes de l'application.")

        # Liste
        lst_frame = tk.Frame(self, bg=COLORS["border"], pady=1)
        lst_frame.pack(fill="x", padx=20, pady=10)
        self.listbox = tk.Listbox(lst_frame, bg=COLORS["input_bg"],
                                   fg=COLORS["text"], font=FONTS["body"],
                                   selectbackground=COLORS["accent_soft"],
                                   selectforeground=COLORS["accent2"],
                                   height=8, relief="flat",
                                   highlightthickness=0)
        self.listbox.pack(fill="x")
        self._refresh_users()

        # Formulaire ajout
        tk.Label(self, text="── Ajouter un utilisateur ──", font=FONTS["small"],
                 fg=COLORS["text_dim"], bg=COLORS["bg_dark"]).pack(pady=(6, 0))

        def row_field(label, var_attr, show=None):
            f = tk.Frame(self, bg=COLORS["bg_dark"])
            f.pack(fill="x", padx=20, pady=2)
            tk.Label(f, text=label, width=16, anchor="w", font=FONTS["label"],
                     fg=COLORS["text_muted"], bg=COLORS["bg_dark"]).pack(side="left")
            var = tk.StringVar()
            kw = dict(textvariable=var, width=28)
            if show:
                kw["show"] = show
            e = tk.Entry(f, **kw)
            _style_entry(e)
            e.pack(side="left", ipady=4)
            setattr(self, var_attr, var)

        row_field("Nom d'utilisateur", "var_new_user")
        row_field("Mot de passe", "var_new_pass", show="●")

        self.var_is_admin = tk.BooleanVar()
        chk = tk.Checkbutton(self, text="Rôle administrateur",
                              variable=self.var_is_admin,
                              font=FONTS["body"],
                              fg=COLORS["text_muted"], bg=COLORS["bg_dark"],
                              activeforeground=COLORS["accent2"],
                              activebackground=COLORS["bg_dark"],
                              selectcolor=COLORS["input_bg"])
        chk.pack(anchor="w", padx=20, pady=4)

        self.lbl_err = tk.Label(self, text="", fg=COLORS["danger"],
                                 bg=COLORS["bg_dark"], font=FONTS["small"])
        self.lbl_err.pack()

        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(pady=8)
        _make_btn(row, "Ajouter",    self._add_user,    "primary").pack(side="left", padx=5)
        _make_btn(row, "Supprimer",  self._del_user,    "danger").pack(side="left", padx=5)
        _make_btn(row, "Fermer",     self.destroy,      "ghost").pack(side="left", padx=5)

    def _refresh_users(self):
        self.listbox.delete(0, "end")
        for u in self.manager.get_users():
            role = "🛡 Admin" if u.is_admin else "👤 Utilisateur"
            self.listbox.insert("end", f"  {u.username}  —  {role}")

    def _add_user(self):
        username = self.var_new_user.get().strip()
        password = self.var_new_pass.get()
        if not username or not password:
            self.lbl_err.configure(text="Nom et mot de passe requis.")
            return
        ok, msg = self.manager.add_user(username, password, self.var_is_admin.get())
        if ok:
            self.lbl_err.configure(text="", fg=COLORS["success"])
            self._refresh_users()
        else:
            self.lbl_err.configure(text=msg, fg=COLORS["danger"])

    def _del_user(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Sélectionnez un utilisateur.")
            return
        username = self.listbox.get(sel[0]).split("—")[0].strip()
        if username == "admin":
            messagebox.showwarning("Erreur", "Impossible de supprimer l'admin principal.")
            return
        self.manager.delete_user(username)
        self._refresh_users()


# ─────────────────────────────────────────────────────────────────────────────
#  AboutDialog
# ─────────────────────────────────────────────────────────────────────────────

class AboutDialog(BaseDialog):
    def __init__(self, parent):
        super().__init__(parent, "À propos", 420, 340)
        self._build()

    def _build(self):
        tk.Label(self, text="◈", font=("Georgia", 48),
                 fg=COLORS["accent2"], bg=COLORS["bg_dark"]).pack(pady=(20, 4))
        tk.Label(self, text="Portfolio Manager", font=("Georgia", 18, "bold"),
                 fg=COLORS["text"], bg=COLORS["bg_dark"]).pack()
        tk.Label(self, text="Version 1.0", font=FONTS["small"],
                 fg=COLORS["text_dim"], bg=COLORS["bg_dark"]).pack()

        tk.Frame(self, bg=COLORS["border"], height=1).pack(fill="x", padx=30, pady=16)

        info = (
            "Application de gestion de portfolio développée\n"
            "en Python avec tkinter (POO).\n\n"
            "Fonctionnalités :\n"
            "• Gestion complète des projets (CRUD)\n"
            "• Gestion des utilisateurs et rôles\n"
            "• Recherche multicritère\n"
            "• Persistance JSON\n"
        )
        tk.Label(self, text=info, font=FONTS["body"],
                 fg=COLORS["text_muted"], bg=COLORS["bg_dark"],
                 justify="left").pack(padx=30)

        _make_btn(self, "Fermer", self.destroy, "ghost").pack(pady=16)
