"""
models.py - Classes métier de l'application Portfolio
"""

import json
import os
import hashlib
from datetime import datetime


class Projet:
    """Représente un projet du portfolio."""

    def __init__(self, libelle, description, technologies, competences,
                 date_creation=None, lien_github="", lien_demo="", image_path=""):
        self.libelle = libelle
        self.description = description
        self.technologies = technologies          # liste de str
        self.competences = competences            # liste de str
        self.date_creation = date_creation or datetime.now().strftime("%Y-%m-%d")
        self.lien_github = lien_github
        self.lien_demo = lien_demo
        self.image_path = image_path

    def to_dict(self):
        return {
            "libelle": self.libelle,
            "description": self.description,
            "technologies": self.technologies,
            "competences": self.competences,
            "date_creation": self.date_creation,
            "lien_github": self.lien_github,
            "lien_demo": self.lien_demo,
            "image_path": self.image_path,
        }

    @staticmethod
    def from_dict(d):
        return Projet(
            libelle=d.get("libelle", ""),
            description=d.get("description", ""),
            technologies=d.get("technologies", []),
            competences=d.get("competences", []),
            date_creation=d.get("date_creation", ""),
            lien_github=d.get("lien_github", ""),
            lien_demo=d.get("lien_demo", ""),
            image_path=d.get("image_path", ""),
        )

    def __str__(self):
        return self.libelle


class Utilisateur:
    """Représente un utilisateur (admin ou visiteur)."""

    def __init__(self, username, password_hash, is_admin=False):
        self.username = username
        self.password_hash = password_hash
        self.is_admin = is_admin

    @staticmethod
    def hash_password(password):
        return hashlib.sha256(password.encode()).hexdigest()

    def check_password(self, password):
        return self.password_hash == Utilisateur.hash_password(password)

    def to_dict(self):
        return {
            "username": self.username,
            "password_hash": self.password_hash,
            "is_admin": self.is_admin,
        }

    @staticmethod
    def from_dict(d):
        return Utilisateur(
            username=d["username"],
            password_hash=d["password_hash"],
            is_admin=d.get("is_admin", False),
        )


class PortfolioManager:
    """Gère la persistance et les opérations sur les projets et utilisateurs."""

    PROJETS_FILE = "data/projets.json"
    USERS_FILE = "data/users.json"

    def __init__(self):
        os.makedirs("data", exist_ok=True)
        self._init_users()
        self.projets = self._load_projets()
        self.current_user = None   # None = visiteur non connecté

    # ── Initialisation ────────────────────────────────────────────────────────

    def _init_users(self):
        """Crée le fichier users avec un admin par défaut si absent."""
        if not os.path.exists(self.USERS_FILE):
            admin = Utilisateur("admin", Utilisateur.hash_password("admin123"), is_admin=True)
            with open(self.USERS_FILE, "w", encoding="utf-8") as f:
                json.dump([admin.to_dict()], f, indent=2, ensure_ascii=False)

    # ── Utilisateurs ──────────────────────────────────────────────────────────

    def _load_users(self):
        with open(self.USERS_FILE, "r", encoding="utf-8") as f:
            return [Utilisateur.from_dict(d) for d in json.load(f)]

    def _save_users(self, users):
        with open(self.USERS_FILE, "w", encoding="utf-8") as f:
            json.dump([u.to_dict() for u in users], f, indent=2, ensure_ascii=False)

    def login(self, username, password):
        for user in self._load_users():
            if user.username == username and user.check_password(password):
                self.current_user = user
                return True
        return False

    def logout(self):
        self.current_user = None

    def is_admin(self):
        return self.current_user is not None and self.current_user.is_admin

    def is_connected(self):
        return self.current_user is not None

    def add_user(self, username, password, is_admin=False):
        users = self._load_users()
        if any(u.username == username for u in users):
            return False, "Nom d'utilisateur déjà pris."
        users.append(Utilisateur(username, Utilisateur.hash_password(password), is_admin))
        self._save_users(users)
        return True, "Utilisateur créé."

    def get_users(self):
        return self._load_users()

    def delete_user(self, username):
        users = self._load_users()
        users = [u for u in users if u.username != username]
        self._save_users(users)

    # ── Projets ───────────────────────────────────────────────────────────────

    def _load_projets(self):
        if not os.path.exists(self.PROJETS_FILE):
            return []
        with open(self.PROJETS_FILE, "r", encoding="utf-8") as f:
            return [Projet.from_dict(d) for d in json.load(f)]

    def _save_projets(self):
        with open(self.PROJETS_FILE, "w", encoding="utf-8") as f:
            json.dump([p.to_dict() for p in self.projets], f, indent=2, ensure_ascii=False)

    def ajouter_projet(self, projet: Projet):
        if not self.is_admin():
            raise PermissionError("Action réservée à l'admin.")
        self.projets.append(projet)
        self._save_projets()

    def get_projets(self):
        return list(self.projets)

    def get_projet_by_libelle(self, libelle):
        for p in self.projets:
            if p.libelle == libelle:
                return p
        return None

    def modifier_projet(self, libelle_original, nouveau_projet: Projet):
        if not self.is_admin():
            raise PermissionError("Action réservée à l'admin.")
        for i, p in enumerate(self.projets):
            if p.libelle == libelle_original:
                self.projets[i] = nouveau_projet
                self._save_projets()
                return True
        return False

    def supprimer_projet(self, libelle):
        if not self.is_admin():
            raise PermissionError("Action réservée à l'admin.")
        avant = len(self.projets)
        self.projets = [p for p in self.projets if p.libelle != libelle]
        if len(self.projets) < avant:
            self._save_projets()
            return True
        return False

    def rechercher_projets(self, terme):
        terme = terme.lower()
        return [p for p in self.projets
                if terme in p.libelle.lower()
                or terme in p.description.lower()
                or any(terme in t.lower() for t in p.technologies)]
