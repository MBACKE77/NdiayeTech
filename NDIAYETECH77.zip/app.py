"""
app.py - Interface graphique principale de l'application Portfolio
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import os
import sys

# Assurer que le dossier courant est dans le path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models import PortfolioManager, Projet
from dialogs import (LoginDialog, ProjetFormDialog, ConfirmDialog,
                     UserManagerDialog, AboutDialog, SearchDialog)


# ─── Palette de couleurs ──────────────────────────────────────────────────────

COLORS = {
    "bg_dark":     "#0f0f1a",
    "bg_card":     "#1a1a2e",
    "bg_sidebar":  "#12122a",
    "accent":      "#7c3aed",
    "accent2":     "#a855f7",
    "accent_soft": "#2d1b69",
    "text":        "#e2e8f0",
    "text_muted":  "#94a3b8",
    "text_dim":    "#475569",
    "success":     "#22c55e",
    "danger":      "#ef4444",
    "warning":     "#f59e0b",
    "border":      "#2d2d4e",
    "hover":       "#252540",
    "selected":    "#3b1f6e",
}

FONTS = {
    "title":   ("Georgia", 22, "bold"),
    "heading": ("Georgia", 14, "bold"),
    "sub":     ("Helvetica", 11, "bold"),
    "body":    ("Helvetica", 10),
    "small":   ("Helvetica", 9),
    "mono":    ("Courier", 10),
    "btn":     ("Helvetica", 10, "bold"),
    "nav":     ("Helvetica", 11),
}


class PortfolioApp(tk.Tk):
    """Fenêtre principale de l'application."""

    def __init__(self):
        super().__init__()
        self.manager = PortfolioManager()
        self.selected_project = None

        self.title("Portfolio Manager")
        self.geometry("1100x700")
        self.minsize(900, 600)
        self.configure(bg=COLORS["bg_dark"])
        self._set_icon()
        self._build_ui()
        self._refresh_project_list()
        self._update_status_bar()

    def _set_icon(self):
        try:
            # Créer une icône simple avec PhotoImage
            img = tk.PhotoImage(width=32, height=32)
            self.iconphoto(True, img)
        except Exception:
            pass

    # ── Construction de l'UI ──────────────────────────────────────────────────

    def _build_ui(self):
        self._build_topbar()
        main = tk.Frame(self, bg=COLORS["bg_dark"])
        main.pack(fill="both", expand=True)
        self._build_sidebar(main)
        self._build_content(main)
        self._build_statusbar()

    def _build_topbar(self):
        bar = tk.Frame(self, bg=COLORS["bg_sidebar"], height=55)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        # Logo / titre
        tk.Label(bar, text="◈ Portfolio", font=FONTS["title"],
                 fg=COLORS["accent2"], bg=COLORS["bg_sidebar"],
                 padx=20).pack(side="left", pady=5)

        tk.Label(bar, text="Manager", font=("Georgia", 22),
                 fg=COLORS["text_muted"], bg=COLORS["bg_sidebar"]).pack(side="left")

        # Boutons de droite
        btn_frame = tk.Frame(bar, bg=COLORS["bg_sidebar"])
        btn_frame.pack(side="right", padx=10)

        self.btn_login = self._make_btn(btn_frame, "🔐 Connexion", self._do_login,
                                        fg=COLORS["accent2"])
        self.btn_login.pack(side="right", padx=4, pady=10)

        self._make_btn(btn_frame, "ℹ À propos", self._show_about,
                       fg=COLORS["text_muted"]).pack(side="right", padx=4, pady=10)

    def _build_sidebar(self, parent):
        side = tk.Frame(parent, bg=COLORS["bg_sidebar"], width=220)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        tk.Label(side, text="ACTIONS", font=FONTS["small"],
                 fg=COLORS["text_dim"], bg=COLORS["bg_sidebar"],
                 pady=8).pack(fill="x", padx=16)

        ttk.Separator(side, orient="horizontal").pack(fill="x", padx=10)

        # Boutons d'action sidebar
        actions = [
            ("📋 Tous les projets",  self._refresh_project_list, "text"),
            ("🔍 Rechercher",        self._do_search, "text"),
            ("➕ Nouveau projet",   self._do_add, "accent"),
            ("✏️  Modifier",          self._do_edit, "accent"),
            ("🗑  Supprimer",        self._do_delete, "danger"),
        ]
        for label, cmd, style in actions:
            self._make_sidebar_btn(side, label, cmd, style)

        ttk.Separator(side, orient="horizontal").pack(fill="x", padx=10, pady=8)

        tk.Label(side, text="ADMIN", font=FONTS["small"],
                 fg=COLORS["text_dim"], bg=COLORS["bg_sidebar"]).pack(fill="x", padx=16)

        self._make_sidebar_btn(side, "👥 Utilisateurs", self._do_manage_users, "muted")
        self._make_sidebar_btn(side, "🔒 Déconnexion",  self._do_logout, "muted")

        # Info utilisateur en bas
        self.lbl_user = tk.Label(side, text="Visiteur", font=FONTS["small"],
                                  fg=COLORS["text_dim"], bg=COLORS["bg_sidebar"],
                                  pady=6, padx=10, anchor="w")
        self.lbl_user.pack(side="bottom", fill="x")

        tk.Label(side, text="Connecté en tant que", font=("Helvetica", 8),
                 fg=COLORS["text_dim"], bg=COLORS["bg_sidebar"],
                 padx=10, anchor="w").pack(side="bottom", fill="x")

    def _build_content(self, parent):
        content = tk.Frame(parent, bg=COLORS["bg_dark"])
        content.pack(side="left", fill="both", expand=True)

        # Panneau gauche : liste
        left = tk.Frame(content, bg=COLORS["bg_dark"], width=280)
        left.pack(side="left", fill="y", padx=(10, 0), pady=10)
        left.pack_propagate(False)

        tk.Label(left, text="Projets", font=FONTS["heading"],
                 fg=COLORS["text"], bg=COLORS["bg_dark"]).pack(anchor="w", padx=4)

        self.lbl_count = tk.Label(left, text="0 projet(s)", font=FONTS["small"],
                                   fg=COLORS["text_muted"], bg=COLORS["bg_dark"])
        self.lbl_count.pack(anchor="w", padx=4)

        # Listbox stylisée
        list_frame = tk.Frame(left, bg=COLORS["border"], pady=1)
        list_frame.pack(fill="both", expand=True, pady=6)

        self.listbox = tk.Listbox(list_frame, bg=COLORS["bg_card"],
                                   fg=COLORS["text"], font=FONTS["body"],
                                   selectbackground=COLORS["accent_soft"],
                                   selectforeground=COLORS["accent2"],
                                   activestyle="none", relief="flat",
                                   highlightthickness=0, borderwidth=0,
                                   cursor="hand2")
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical",
                                   command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scrollbar.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.listbox.bind("<<ListboxSelect>>", self._on_select)
        self.listbox.bind("<Double-Button-1>", lambda e: self._show_detail())

        # Panneau droit : détail
        right = tk.Frame(content, bg=COLORS["bg_dark"])
        right.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        self.detail_frame = tk.Frame(right, bg=COLORS["bg_card"],
                                      bd=0, highlightbackground=COLORS["border"],
                                      highlightthickness=1)
        self.detail_frame.pack(fill="both", expand=True)
        self._show_welcome()

    def _build_statusbar(self):
        bar = tk.Frame(self, bg=COLORS["bg_sidebar"], height=28)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        self.status_var = tk.StringVar(value="Prêt")
        tk.Label(bar, textvariable=self.status_var, font=FONTS["small"],
                 fg=COLORS["text_dim"], bg=COLORS["bg_sidebar"],
                 anchor="w", padx=10).pack(side="left", fill="y")
        self.lbl_role = tk.Label(bar, text="● Visiteur", font=FONTS["small"],
                                  fg=COLORS["text_dim"], bg=COLORS["bg_sidebar"],
                                  padx=10)
        self.lbl_role.pack(side="right")

    # ── Helpers UI ────────────────────────────────────────────────────────────

    def _make_btn(self, parent, text, cmd, fg=None, bg=None):
        fg = fg or COLORS["text"]
        bg = bg or COLORS["bg_sidebar"]
        btn = tk.Button(parent, text=text, command=cmd,
                        font=FONTS["btn"], fg=fg, bg=bg,
                        relief="flat", cursor="hand2",
                        activeforeground=COLORS["accent2"],
                        activebackground=COLORS["accent_soft"],
                        padx=10, pady=4, bd=0)
        return btn

    def _make_sidebar_btn(self, parent, text, cmd, style="text"):
        colors = {
            "text":   (COLORS["text"], COLORS["bg_sidebar"]),
            "accent": (COLORS["accent2"], COLORS["bg_sidebar"]),
            "danger": (COLORS["danger"], COLORS["bg_sidebar"]),
            "muted":  (COLORS["text_muted"], COLORS["bg_sidebar"]),
        }
        fg, bg = colors.get(style, colors["text"])
        btn = tk.Button(parent, text=text, command=cmd,
                        font=FONTS["nav"], fg=fg, bg=bg,
                        relief="flat", cursor="hand2", anchor="w",
                        activeforeground=COLORS["accent2"],
                        activebackground=COLORS["hover"],
                        padx=16, pady=7, bd=0)
        btn.pack(fill="x")
        btn.bind("<Enter>", lambda e: btn.configure(bg=COLORS["hover"]))
        btn.bind("<Leave>", lambda e: btn.configure(bg=COLORS["bg_sidebar"]))
        return btn

    def _clear_detail(self):
        for w in self.detail_frame.winfo_children():
            w.destroy()

    def _show_welcome(self):
        self._clear_detail()
        f = self.detail_frame
        tk.Label(f, text="\n\n◈", font=("Georgia", 48),
                 fg=COLORS["accent_soft"], bg=COLORS["bg_card"]).pack()
        tk.Label(f, text="Bienvenue dans Portfolio Manager",
                 font=FONTS["heading"], fg=COLORS["text"],
                 bg=COLORS["bg_card"]).pack(pady=4)
        tk.Label(f, text="Sélectionnez un projet dans la liste\nou double-cliquez pour voir les détails.",
                 font=FONTS["body"], fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"], justify="center").pack()

    def _show_detail(self, projet=None):
        if projet is None:
            projet = self.selected_project
        if projet is None:
            return
        self._clear_detail()
        f = self.detail_frame

        canvas = tk.Canvas(f, bg=COLORS["bg_card"], highlightthickness=0)
        vsb = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=COLORS["bg_card"])
        win = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_resize(e):
            canvas.itemconfig(win, width=e.width)
        canvas.bind("<Configure>", _on_resize)
        inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))

        pad = {"padx": 20, "pady": 4}

        # En-tête
        header = tk.Frame(inner, bg=COLORS["accent_soft"])
        header.pack(fill="x", padx=0, pady=(0, 12))
        tk.Label(header, text=projet.libelle, font=FONTS["title"],
                 fg=COLORS["accent2"], bg=COLORS["accent_soft"],
                 wraplength=520, justify="left",
                 padx=20, pady=16).pack(anchor="w")
        tk.Label(header, text=f"📅 {projet.date_creation}",
                 font=FONTS["small"], fg=COLORS["text_muted"],
                 bg=COLORS["accent_soft"], padx=20, pady=4).pack(anchor="w")

        def section(title, content_fn):
            tk.Label(inner, text=title, font=FONTS["sub"],
                     fg=COLORS["accent2"], bg=COLORS["bg_card"],
                     **pad).pack(anchor="w")
            content_fn()
            tk.Frame(inner, bg=COLORS["border"], height=1).pack(
                fill="x", padx=20, pady=6)

        def desc():
            tk.Label(inner, text=projet.description or "(aucune description)",
                     font=FONTS["body"], fg=COLORS["text"],
                     bg=COLORS["bg_card"], wraplength=500, justify="left",
                     **pad).pack(anchor="w")

        def techno():
            row = tk.Frame(inner, bg=COLORS["bg_card"])
            row.pack(anchor="w", padx=20, pady=4)
            techs = projet.technologies if isinstance(projet.technologies, list) \
                else [t.strip() for t in str(projet.technologies).split(",")]
            for t in techs:
                if t.strip():
                    tk.Label(row, text=t.strip(), font=FONTS["small"],
                             fg=COLORS["bg_dark"], bg=COLORS["accent2"],
                             padx=8, pady=2, relief="flat").pack(
                             side="left", padx=2)

        def comps():
            comps_list = projet.competences if isinstance(projet.competences, list) \
                else [c.strip() for c in str(projet.competences).split(",")]
            for c in comps_list:
                if c.strip():
                    tk.Label(inner, text=f"  ✓  {c.strip()}", font=FONTS["body"],
                             fg=COLORS["success"], bg=COLORS["bg_card"],
                             padx=20).pack(anchor="w")

        def liens():
            if projet.lien_github:
                tk.Label(inner, text=f"🔗 GitHub : {projet.lien_github}",
                         font=FONTS["body"], fg=COLORS["accent2"],
                         bg=COLORS["bg_card"], **pad).pack(anchor="w")
            if projet.lien_demo:
                tk.Label(inner, text=f"🌐 Démo : {projet.lien_demo}",
                         font=FONTS["body"], fg=COLORS["accent2"],
                         bg=COLORS["bg_card"], **pad).pack(anchor="w")

        section("📝 Description", desc)
        section("🛠 Technologies utilisées", techno)
        section("🎓 Compétences acquises", comps)
        if projet.lien_github or projet.lien_demo:
            section("🔗 Liens", liens)

        # Boutons d'action en bas
        btn_row = tk.Frame(inner, bg=COLORS["bg_card"])
        btn_row.pack(pady=16)
        if self.manager.is_admin():
            self._make_btn(btn_row, "✏️ Modifier", self._do_edit,
                           fg=COLORS["accent2"]).pack(side="left", padx=6)
            self._make_btn(btn_row, "🗑 Supprimer", self._do_delete,
                           fg=COLORS["danger"]).pack(side="left", padx=6)

    # ── Refresh ───────────────────────────────────────────────────────────────

    def _refresh_project_list(self, projets=None):
        self.listbox.delete(0, "end")
        projets = projets if projets is not None else self.manager.get_projets()
        for p in projets:
            self.listbox.insert("end", f"  {p.libelle}")
        self.lbl_count.configure(text=f"{len(projets)} projet(s)")
        self._set_status(f"{len(projets)} projet(s) chargé(s).")

    def _update_status_bar(self):
        if self.manager.is_admin():
            self.lbl_role.configure(text="● Admin", fg=COLORS["success"])
            self.lbl_user.configure(text=self.manager.current_user.username)
            self.btn_login.configure(text="🔑 " + self.manager.current_user.username)
        elif self.manager.is_connected():
            self.lbl_role.configure(text="● Connecté", fg=COLORS["warning"])
            self.lbl_user.configure(text=self.manager.current_user.username)
            self.btn_login.configure(text="🔑 " + self.manager.current_user.username)
        else:
            self.lbl_role.configure(text="● Visiteur", fg=COLORS["text_dim"])
            self.lbl_user.configure(text="Visiteur")
            self.btn_login.configure(text="🔐 Connexion")

    def _set_status(self, msg):
        self.status_var.set(msg)

    # ── Événements ────────────────────────────────────────────────────────────

    def _on_select(self, event):
        sel = self.listbox.curselection()
        if not sel:
            return
        libelle = self.listbox.get(sel[0]).strip()
        self.selected_project = self.manager.get_projet_by_libelle(libelle)
        if self.selected_project:
            self._show_detail(self.selected_project)

    # ── Actions ───────────────────────────────────────────────────────────────

    def _do_login(self):
        if self.manager.is_connected():
            self._do_logout()
            return
        dlg = LoginDialog(self, self.manager)
        self.wait_window(dlg)
        self._update_status_bar()
        if self.manager.is_connected():
            self._set_status(f"Connecté en tant que {self.manager.current_user.username}.")

    def _do_logout(self):
        self.manager.logout()
        self._update_status_bar()
        self._set_status("Déconnecté.")
        self._show_welcome()

    def _do_add(self):
        if not self.manager.is_admin():
            messagebox.showwarning("Accès refusé",
                                   "Seul un administrateur peut ajouter un projet.")
            return
        dlg = ProjetFormDialog(self, title="Nouveau projet")
        self.wait_window(dlg)
        if dlg.result:
            try:
                self.manager.ajouter_projet(dlg.result)
                self._refresh_project_list()
                self._set_status(f"Projet « {dlg.result.libelle} » ajouté.")
            except Exception as e:
                messagebox.showerror("Erreur", str(e))

    def _do_edit(self):
        if not self.manager.is_admin():
            messagebox.showwarning("Accès refusé",
                                   "Seul un administrateur peut modifier un projet.")
            return
        if not self.selected_project:
            messagebox.showinfo("Info", "Veuillez d'abord sélectionner un projet.")
            return
        dlg = ProjetFormDialog(self, title="Modifier le projet",
                               projet=self.selected_project)
        self.wait_window(dlg)
        if dlg.result:
            try:
                old_libelle = self.selected_project.libelle
                self.manager.modifier_projet(old_libelle, dlg.result)
                self.selected_project = dlg.result
                self._refresh_project_list()
                self._show_detail(dlg.result)
                self._set_status(f"Projet « {dlg.result.libelle} » modifié.")
            except Exception as e:
                messagebox.showerror("Erreur", str(e))

    def _do_delete(self):
        if not self.manager.is_admin():
            messagebox.showwarning("Accès refusé",
                                   "Seul un administrateur peut supprimer un projet.")
            return
        if not self.selected_project:
            messagebox.showinfo("Info", "Veuillez d'abord sélectionner un projet.")
            return
        dlg = ConfirmDialog(self,
                            f"Supprimer « {self.selected_project.libelle} » ?",
                            "Cette action est irréversible.")
        self.wait_window(dlg)
        if dlg.confirmed:
            libelle = self.selected_project.libelle
            self.manager.supprimer_projet(libelle)
            self.selected_project = None
            self._refresh_project_list()
            self._show_welcome()
            self._set_status(f"Projet « {libelle} » supprimé.")

    def _do_search(self):
        dlg = SearchDialog(self, self.manager)
        self.wait_window(dlg)
        if dlg.results is not None:
            self._refresh_project_list(dlg.results)
            self._set_status(f"{len(dlg.results)} résultat(s) trouvé(s).")

    def _do_manage_users(self):
        if not self.manager.is_admin():
            messagebox.showwarning("Accès refusé",
                                   "Seul un administrateur peut gérer les utilisateurs.")
            return
        dlg = UserManagerDialog(self, self.manager)
        self.wait_window(dlg)

    def _show_about(self):
        dlg = AboutDialog(self)
        self.wait_window(dlg)


def main():
    app = PortfolioApp()
    app.mainloop()


if __name__ == "__main__":
    main()
