# Portfolio Manager — Application Python POO avec interface graphique

## Description
Application desktop de gestion de portfolio de projets, développée en Python avec
tkinter (interface graphique) et une architecture orientée objet.

---

## Prérequis
- Python 3.8 ou supérieur
- tkinter (inclus par défaut avec Python sur Windows et macOS)
  - Sur Ubuntu/Debian : `sudo apt-get install python3-tk`

---

## Lancement

### 1. Insérer des projets de démonstration (optionnel)
```bash
python seed_data.py
```

### 2. Lancer l'application
```bash
python app.py
```

---

## Compte administrateur par défaut
- **Utilisateur** : `admin`
- **Mot de passe** : `admin123`

> ⚠️ Changez ce mot de passe après la première connexion.

---

## Fonctionnalités

### Visiteur (non connecté)
- Consulter la liste des projets
- Afficher le détail d'un projet (description, technologies, compétences)

### Administrateur (connecté)
- Tout ce que peut faire le visiteur, plus :
- Ajouter un nouveau projet
- Modifier un projet existant
- Supprimer un projet
- Gérer les comptes utilisateurs
- Rechercher des projets par mot-clé

---

## Structure du projet
```
portfolio_app/
├── app.py          # Fenêtre principale et logique de navigation
├── dialogs.py      # Boîtes de dialogue (login, formulaire, etc.)
├── models.py       # Classes métier : Projet, Utilisateur, PortfolioManager
├── seed_data.py    # Script de données de démonstration
├── README.md       # Ce fichier
└── data/           # Créé automatiquement au premier lancement
    ├── projets.json
    └── users.json
```

---

## Modélisation d'un projet
Un projet possède les attributs suivants :
| Attribut         | Description                              |
|------------------|------------------------------------------|
| `libelle`        | Nom du projet (identifiant unique)       |
| `description`    | Présentation détaillée du projet         |
| `technologies`   | Liste des technologies utilisées         |
| `competences`    | Liste des compétences acquises           |
| `date_creation`  | Date de création (YYYY-MM-DD)            |
| `lien_github`    | URL du dépôt GitHub (optionnel)          |
| `lien_demo`      | URL de la démo en ligne (optionnel)      |

---

## Ajouts spécifiques (bonus)
1. **Recherche multicritère** : recherche par libellé, description ou technologie.
2. **Liens GitHub et démo** : chaque projet peut contenir des liens vers son code source et sa démonstration en ligne.
3. **Gestion des utilisateurs** : l'admin peut créer et supprimer des comptes directement depuis l'interface.
4. **Données de démonstration** : script `seed_data.py` pour pré-remplir l'application.
